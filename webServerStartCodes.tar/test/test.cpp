#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080

void handle_client(int client_socket) {
    const int BUFFER_SIZE = 4096;
    char buffer[BUFFER_SIZE];
    bzero(buffer, BUFFER_SIZE);

    // 接收HTTP请求
    int bytes_read = recv(client_socket, buffer, BUFFER_SIZE, 0);
    if (bytes_read <= 0) {
        std::cerr << "Error reading from socket or connection closed by client" << std::endl;
        return;
    }

    // 检查Connection头部以确定是否持久连接
    std::string request(buffer, bytes_read);
    std::string connection_header = "Connection: ";
    size_t pos = request.find(connection_header);
    bool keep_alive = false;

    if (pos != std::string::npos) {
        size_t end_pos = request.find("\r\n", pos);
        std::string header_value = request.substr(pos + connection_header.size(), end_pos - pos - connection_header.size());
        keep_alive = (header_value.find("keep-alive") != std::string::npos);
    }

    // 构建HTTP响应
    std::string response = "HTTP/1.1 200 OK\r\n";
    response += "Content-Type: text/html\r\n";
    response += "Connection: " + (std::string)(keep_alive ? "keep-alive" : "close") + "\r\n\r\n";
    response += "<html><body><h1>Hello, World!</h1></body></html>";

    // 发送HTTP响应
    send(client_socket, response.c_str(), response.size(), 0);

    // 如果不是持久连接，则关闭socket
    if (!keep_alive) {
        close(client_socket);
    }
}

int main() {
    int server_socket, client_socket;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_len = sizeof(client_addr);

    // 创建socket
    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket < 0) {
        std::cerr << "Cannot open socket" << std::endl;
        return 1;
    }

    // 绑定socket
    bzero((char *) &server_addr, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);
    if (bind(server_socket, (struct sockaddr *) &server_addr, sizeof(server_addr)) < 0) {
        std::cerr << "Cannot bind" << std::endl;
        return 1;
    }

    // 监听连接
    listen(server_socket, 5);
    std::cout << "Server listening on port " << PORT << "..." << std::endl;

    while (true) {
        // 接受连接
        client_socket = accept(server_socket, (struct sockaddr *) &client_addr, &client_len);
        if (client_socket < 0) {
            std::cerr << "Cannot accept connection" << std::endl;
            return 1;
        }

        std::cout << "Accepted connection from " << inet_ntoa(client_addr.sin_addr) << std::endl;

        // 处理客户端请求
        handle_client(client_socket);
    }

    close(server_socket);
    return 0;
}