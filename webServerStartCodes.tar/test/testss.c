#include <stdio.h>
#include <string.h>
main()
{
    char *s="GoldenGlobalView";
    char *l="lob";
    char *p;
    p=strstr(s,l);
    if(p)
        printf("%d",p-s+1);
    else
        printf("NotFound!");
    return 0;
}
