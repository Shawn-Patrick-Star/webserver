#!/bin/bash

./liso_client localhost 9999