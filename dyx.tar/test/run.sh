#!/bin/bash
gcc server_select.c -o server
gcc client.c -o client