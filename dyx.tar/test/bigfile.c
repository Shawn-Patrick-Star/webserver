#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Buffer
{
    char *buf;
    int length;
    int capacity;
} Buffer;

void init_buffer(Buffer* buffer, int capacity){
    buffer->buf = (char *)malloc(capacity);
    if(buffer->buf == NULL){
        // ERROR_LOG
        return;
    }
    memset(buffer->buf, 0, capacity);
    buffer->length = 0;
    buffer->capacity = capacity;
}

void append_buffer(Buffer* buffer, char *data, int len){
    if(buffer->length + len > buffer->capacity){
        char *newBuffer = (char *)malloc(buffer->capacity * 2);
        strncpy(newBuffer, buffer->buf, buffer->length);
        free(buffer->buf);
        buffer->buf = newBuffer;
        buffer->capacity *= 2;
    }
    for(int i = 0; i < len; i++){
        buffer->buf[buffer->length + i] = data[i];
    }
    buffer->length += len;
}

void clear_buffer(Buffer* buffer){
    memset(buffer->buf, 0, buffer->length);
    buffer->length = 0;
}

void free_buffer(Buffer* buffer){
    free(buffer->buf);
}



int main() {
    FILE *fp;
    Buffer buffer;
    init_buffer(&buffer, 1024);


    fp = fopen("example.txt", "rb");
    if (fp == NULL) {
        perror("file open failed");
        exit(EXIT_FAILURE);
    }
    char temp[1024];
    size_t cur_len = 0;  // 已读取字节数
    while (!feof(fp)) {
        size_t len = fread(temp, 1, 1024, fp);
        printf("\33[1;35m" "%ld " "\33[0m", len);
        append_buffer(&buffer, temp, len);
        cur_len += len;
    }
    printf("\n" "\33[1;35m" "%ld" "\33[0m" "\n", cur_len);
    printf("\33[1;35m" "%d" "\33[0m" "\n", buffer.length);
    printf("\33[1;35m" "%d" "\33[0m" "\n", buffer.capacity);
    
    fclose(fp);

    // 处理缓冲区中的文件内容
    // ...
    printf("%s\n", buffer.buf);
    free_buffer(&buffer);
    return 0;
}